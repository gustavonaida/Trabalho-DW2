import "../css/DespesaItem.css";

export default function DespesaItem() {
  return (
    <div>
      <h2></h2>
    </div>
  );
}
