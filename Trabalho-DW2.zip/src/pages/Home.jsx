import DespesaItem from "../components/DespesaFixa";
import "../css/Home.css";

function Home() {
  return (
    <div id="home-page">
      <div className="colunas">
        <DespesaItem />
      </div>
    </div>
  );
}

export default Home;
