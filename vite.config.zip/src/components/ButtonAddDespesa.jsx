function ButtonAddDespesa({ onClick }) {
  return (
    <div className="despesa-item" id="adicionar-despesa" onClick={onClick}>
      +
    </div>
  );
}

export default ButtonAddDespesa;
