import "../css/DespesaItem.css";

function BtnAdicionar() {
  return (
    <div className="despesa-item" id="adicionar-despesa">
      +
    </div>
  );
}

export default BtnAdicionar;
