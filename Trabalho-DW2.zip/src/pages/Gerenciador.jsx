import "../css/Gerenciador.css";

export default function Gerenciador() {
  return (
    <div id="gerenciador-page">
      <h1>Gerenciar Despesas:</h1>
    </div>
  );
}
