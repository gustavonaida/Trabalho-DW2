import "../css/Graficos.css";

export default function Graficos() {
  return (
    <div id="graficos-page">
      <h1>Gráficos para Comparação:</h1>
    </div>
  );
}
